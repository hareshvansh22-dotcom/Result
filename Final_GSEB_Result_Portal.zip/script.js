let rows=[];
fetch('results.csv').then(r=>r.text()).then(t=>{
let l=t.trim().split('\n'); let h=l.shift().split(',');
rows=l.map(x=>x.split(','));
window.headers=h;
});
function findResult(){
let gr=document.getElementById('gr').value.trim();
let dob=document.getElementById('dob').value.trim();
let r=rows.find(v=>v[0]==gr && v[1]==dob);
if(!r){document.getElementById('result').innerHTML='Result Not Found';return;}
document.getElementById('result').innerHTML=`<h2>${r[2]}</h2>
<p>Total: ${r[10]}</p><p>Percentage: ${r[12]}%</p><p>Result: ${r[14]}</p>
<button onclick="window.print()">Download PDF</button>`;
}